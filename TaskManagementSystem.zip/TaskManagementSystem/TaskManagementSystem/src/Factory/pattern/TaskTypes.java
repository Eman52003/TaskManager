package Factory.pattern;

import models.*;

public class TaskTypes {
    public Task createTask(String type, String name, String description, String deadline) {
        switch (type.toLowerCase()) {
            case "bug":
                return new BugTask(name, description, deadline);
            case "feature":
                return new FeatureTask(name, description, deadline);
            case "improvement":  // إضافة النوع الجديد
                return new Improvement(name, description, deadline);
            default:
                throw new IllegalArgumentException("Unknown task type: " + type);
        }
    }
}
