package Factory.pattern;

import Role.Types.AdminRole;
import Role.Types.DeveloperRole;
import Role.Types.TesterRole;
import Role.Types.UserRole;

public class UserRoleFactory {
    public UserRole createUserRole(String roleType, String name) {
        switch (roleType.toLowerCase()) {
            case "admin":
                return new AdminRole(name);
            case "developer":
                return new DeveloperRole(name);
            case "tester":
                return new TesterRole(name);
            default:
                throw new IllegalArgumentException("Unknown role type: " + roleType);
        }
    }
}
