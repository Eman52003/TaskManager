package TaskManagementGUI;

import Factory.pattern.TaskTypes;
import Factory.pattern.UserRoleFactory;
import Role.Types.UserRole;
import models.Task;
import singleton.pattern.TaskManager;
import singleton.pattern.NotificationSystem;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TaskManagementGUI {
    public TaskManagementGUI() {
        // إنشاء النافذة
        JFrame frame = new JFrame("Task and User Management");
        frame.setSize(500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        // إعداد الحقول والعناصر الرسومية
        JLabel nameLabel = new JLabel("Task Name:");
        nameLabel.setBounds(20, 20, 100, 30);
        JTextField nameField = new JTextField();
        nameField.setBounds(120, 20, 200, 30);

        JLabel typeLabel = new JLabel("Task Type:");
        typeLabel.setBounds(20, 60, 100, 30);
        JComboBox<String> typeComboBox = new JComboBox<>(new String[]{"Bug", "Feature", "Improvement"});  // إضافة النوع الجديد
        typeComboBox.setBounds(120, 60, 200, 30);

        JLabel descriptionLabel = new JLabel("Description:");
        descriptionLabel.setBounds(20, 100, 100, 30);
        JTextField descriptionField = new JTextField();
        descriptionField.setBounds(120, 100, 200, 30);

        JLabel deadlineLabel = new JLabel("Deadline:");
        deadlineLabel.setBounds(20, 140, 100, 30);
        JTextField deadlineField = new JTextField();
        deadlineField.setBounds(120, 140, 200, 30);

        JButton addTaskButton = new JButton("Add Task");
        addTaskButton.setBounds(120, 180, 100, 30);

        // قسم إدارة المستخدمين
        JLabel userNameLabel = new JLabel("User Name:");
        userNameLabel.setBounds(20, 230, 100, 30);
        JTextField userNameField = new JTextField();
        userNameField.setBounds(120, 230, 200, 30);

        JLabel roleLabel = new JLabel("Role:");
        roleLabel.setBounds(20, 270, 100, 30);
        JComboBox<String> roleComboBox = new JComboBox<>(new String[]{"Admin", "Developer", "Tester"});
        roleComboBox.setBounds(120, 270, 200, 30);

        JButton addUserButton = new JButton("Add User");
        addUserButton.setBounds(120, 310, 100, 30);

        // إعداد التخطيط
        frame.setLayout(null);
        frame.add(nameLabel);
        frame.add(nameField);
        frame.add(typeLabel);
        frame.add(typeComboBox);
        frame.add(descriptionLabel);
        frame.add(descriptionField);
        frame.add(deadlineLabel);
        frame.add(deadlineField);
        frame.add(addTaskButton);
        frame.add(userNameLabel);
        frame.add(userNameField);
        frame.add(roleLabel);
        frame.add(roleComboBox);
        frame.add(addUserButton);

        frame.setVisible(true);

        // التأكد من وجود الكلاسات Singleton
        TaskTypes taskFactory = new TaskTypes();
        TaskManager manager = TaskManager.getInstance();
        NotificationSystem notifications = NotificationSystem.getInstance();

        // مصنع الأدوار
        UserRoleFactory roleFactory = new UserRoleFactory();

        // زر إضافة المهمة
        addTaskButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                String type = (String) typeComboBox.getSelectedItem();
                String description = descriptionField.getText().trim();
                String deadline = deadlineField.getText().trim();

                if (name.isEmpty() || description.isEmpty() || deadline.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    Task task = taskFactory.createTask(type, name, description, deadline);
                    manager.addTask(task);

                    notifications.notify("Task Added: " + name);
                    JOptionPane.showMessageDialog(frame, "Task Added Successfully");

                    nameField.setText("");
                    descriptionField.setText("");
                    deadlineField.setText("");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, "Error creating task: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });

        // زر إضافة المستخدم
        addUserButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userName = userNameField.getText().trim();
                String role = (String) roleComboBox.getSelectedItem();

                if (userName.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "User name must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    UserRole userRole = roleFactory.createUserRole(role, userName);
                    notifications.notify("User Added: " + userName + " as " + role);
                    JOptionPane.showMessageDialog(frame, "User Added Successfully");

                    userNameField.setText("");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, "Error creating user: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });
    }

    public static void main(String[] args) {
        new TaskManagementGUI();
    }
}
