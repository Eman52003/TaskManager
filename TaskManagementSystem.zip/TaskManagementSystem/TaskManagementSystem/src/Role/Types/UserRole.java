package Role.Types;

public abstract class UserRole {
    protected String name;

    public UserRole(String name) {
        this.name = name;
    }

    public abstract void performRole();
}
