package Role.Types;

public class TesterRole extends UserRole {
    public TesterRole(String name) {
        super(name);
    }

    @Override
    public void performRole() {
        System.out.println("Tester " + name + " is testing the system.");
    }
}
