package Role.Types;

public class AdminRole extends UserRole {
    public AdminRole(String name) {
        super(name);
    }

    @Override
    public void performRole() {
        System.out.println("Admin " + name + " is managing the system and tasks.");
    }
}
