package Role.Types;

public class DeveloperRole extends UserRole {
    public DeveloperRole(String name) {
        super(name);
    }

    @Override
    public void performRole() {
        System.out.println("Developer " + name + " is developing new features.");
    }
}
