package singleton.pattern;

public class NotificationSystem {
    private static NotificationSystem instance;

    private NotificationSystem() {}

    public static NotificationSystem getInstance() {
        if (instance == null) {
            instance = new NotificationSystem();
        }
        return instance;
    }

    public void notify(String message) {
        System.out.println("Notification: " + message);
    }
}
