package models;

public class Improvement extends Task {
    public Improvement(String name, String description, String deadline) {
        super(name, description, deadline);
    }

    @Override
    public void execute() {
        System.out.println("Executing Bug Task: " + name);
    }
}
