package models;

public class FeatureTask extends Task {
    public FeatureTask(String name, String description, String deadline) {
        super(name, description, deadline);
    }

    @Override
    public void execute() {
        System.out.println("Executing Feature Task: " + name);
    }
}
