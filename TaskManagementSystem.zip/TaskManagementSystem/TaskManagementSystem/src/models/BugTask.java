package models;

public class BugTask extends Task {
    public BugTask(String name, String description, String deadline) {
        super(name, description, deadline);
    }

    @Override
    public void execute() {
        System.out.println("Executing Bug Task: " + name);
    }
}
